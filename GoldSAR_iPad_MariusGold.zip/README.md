# GoldSAR V1 Demo – Pepperstone / cTrader

Ein cTrader-cBot für Gold (XAUUSD), **ausschließlich für ein Pepperstone-Demokonto in EUR**.

**Kein Versprechen auf Tagesgewinne.** Das Ziel von 10 € realisiertem Nettogewinn je UTC-Tag ist ein Limit für *weitere Einstiege*, kein Handelszwang. Bei ungünstigen Bedingungen handelt der Bot nicht.

## Strategie
- M15-Chart, Parabolic SAR + EMA 50/200 + RSI 14, ATR-Stop.
- Long- und Short-Positionen, ein Bot-Trade zur Zeit.
- 0,5 % nominelles Risiko pro Trade, maximal 2 neue Trades täglich.
- Kein neuer Trade nach 10 € realisiertem Netto-Tagesgewinn.
- Stopp bei ca. 2 % Tagesverlust (realisierter plus offener Bot-P&L), unter Annahme eines dedizierten Demo-Kontos.
- Neue Trades nur von 07:00 bis 18:00 UTC; alle Bot-Positionen werden nach 19:00 UTC bei verfügbarem Tick geschlossen.
- Echtgeldkonten werden im Code blockiert.

## GitHub Actions
Die Datei `.github/workflows/build.yml` kompiliert das Projekt mit .NET 8 und `cTrader.Automate 1.0.21`. Nach erfolgreichem Build steht die erzeugte `.algo`-Datei als herunterladbares Artifact bereit. Ein erfolgreicher Build ist **kein Backtest**.

## Einschränkungen
- Demoprototyp, noch kein bestätigter erfolgreicher Build oder Backtest.
- Die tägliche Trade-Anzahl und der realisierte P&L werden aus verfügbarer Broker-Historie ermittelt; fehlende Historie und parallele Bot-Instanzen können Grenzen beeinträchtigen.
- Der Laufzeit-Höchststand der Equity wird bei Cloud-Neustart zurückgesetzt.
- Die Rechnung setzt ein dediziertes EUR-Demokonto ohne Einzahlungen/Auszahlungen oder Trades anderer Bots voraus.
- Gebühren, Slippage, Spreads, Mindestpositionsgrößen und Ausfälle können Limits überschreiten bzw. Trades verhindern.
- **Dieses Repository ist möglicherweise öffentlich. Keine Zugangsdaten oder Tokens committen.**

**Anleitung:** [ANLEITUNG_IPAD.md](ANLEITUNG_IPAD.md).
