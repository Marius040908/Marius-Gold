# GoldSAR: Einrichtung mit iPad – GitHub → cTrader → Pepperstone

## Vorbereitung
- Ein kostenloses GitHub-Konto; Repo `Marius040908/Marius-Gold`.
- iPad mit Safari und Dateien-App sowie cTrader-App für dein Pepperstone-Konto.
- **Pepperstone-cTrader-Demokonto in EUR**. Kein Echtgeldkonto.
- Am besten nur diesen Bot auf dem Demokonto nutzen. Kein Pepperstone-Passwort in GitHub eingeben.

## A – Projekt zu GitHub bringen, falls noch nicht hochgeladen
1. Öffne `https://github.com/Marius040908/Marius-Gold` in Safari.
2. Wenn das Repo leer ist: `Add a README` bzw. `creating a new file` wählen und eine Datei `README.md` mit einem kurzen Platzhalter anlegen (`Commit changes`).
3. Im Repository auf `Code` → `Codespaces` → `Create codespace on main` tippen. Dieser Cloud-Editor funktioniert im iPad-Browser; GitHub-Free-Kontingente beachten.
4. Die heruntergeladene ZIP `GoldSAR_iPad_MariusGold.zip` in der App Dateien speichern.
5. Im Codespaces-Editor im Explorer die ZIP über `Upload Files` in den Projektordner hochladen. Terminal → New Terminal öffnen und folgende Befehle ausführen:

```bash
unzip -o GoldSAR_iPad_MariusGold.zip
ls -la
ls .github/workflows/
git add README.md ANLEITUNG_IPAD.md GoldSARV1Demo.cs GoldSARV1Demo.csproj .gitignore .github/workflows/build.yml
git commit -m "Add GoldSAR Pepperstone demo bot and build workflow"
git push origin main
```

6. Codespace schließen/stoppen, um kein unnötiges Kontingent zu verbrauchen.

## B – cTrader-Datei automatisch kompilieren
1. Auf GitHub ins Repo gehen → `Actions`.
2. Falls nötig Actions aktivieren. Den Workflow `Build GoldSAR demo cBot` auswählen.
3. Auf das neueste Workflow-Ergebnis tippen. Nur bei **grünem Haken** fortfahren.
4. Ganz unten unter `Artifacts` die ZIP `GoldSARV1Demo-ALGO` herunterladen.
5. In der iPad-Dateien-App ZIP antippen, entpacken und die enthaltene **`.algo`**-Datei suchen.
6. Scheitert die Aktion, in `Build GoldSAR demo cBot` → `compile` → roter Schritt schauen und Fehlermeldung in ChatGPT teilen. **Nicht ungeprüften Code ausführen.**

## C – Bei Pepperstone mit cTrader installieren
1. Pepperstone öffnen und ein **cTrader DEMO**-Handelskonto mit Kontowährung **EUR** anlegen, falls noch keines besteht.
2. In der **cTrader-App** mit der cTrader-ID anmelden, die zum Pepperstone-Demokonto gehört. Prüfen, ob das Konto tatsächlich als DEMO angezeigt wird.
3. In cTrader zu **Algo / cBots** gehen, **Upload** auswählen und die `.algo`-Datei aus der Dateien-App laden. Alternativ die Datei in Dateien antippen und mit cTrader öffnen.
4. Den Bot `GoldSARV1Demo` wählen → **Add instance**. Als Konto das Pepperstone-EUR-Demokonto, als Symbol Gold / XAUUSD (Broker-Bezeichnung) und als Zeitraum **M15** wählen.
5. Einstellungen zunächst unverändert lassen: Tagesziel 10 EUR, Risiko 0,5 %, Tagesverlust 2 %, maximal 2 Trades.
6. Die **Cloud-Instanz** starten. Die iPad-App muss anschließend nicht geöffnet bleiben. Einschränkungen des Demo-Kontos/Cloud-Anbieters beachten.
7. In cTrader Positionen und Bot-Logs prüfen. Wenn der Bot wegen Broker, Währung, Kontotyp oder Mindestvolumen stoppt bzw. Trades auslässt, nicht durch höheres Risiko umgehen.

## D – Sicherheitsprüfung vor längerer Demo
- `Account.IsLive == false`, Kontowährung `EUR`, `BrokerName` enthält `Pepperstone`, Symbol `XAU`/`GOLD`, M15.
- Bei weniger als etwa 100–500 EUR Demo-Budget kann bereits die kleinste Gold-Position zu groß sein: Der Bot soll dann aussetzen.
- Die 10 € sind nur ein Zielwert und können auch über lange Zeit vollständig verfehlt werden.
- **Es wurde noch kein historischer Backtest und kein verifizierter cTrader-Live-Build ausgeführt.** Zuerst Build, Backtest (über einen geeigneten cTrader-Desktop-/CLI-Testzugang) und Demo-Auswertung prüfen.
- Keine Gewinne garantieren. Bei Fehlern oder unerwarteten Positionen Bot in cTrader stoppen.

Offizielle Dokumentation:
- https://help.ctrader.com/cbots/how-tos/install-a-cbot/
- https://help.ctrader.com/ctrader-algo/documentation/cbots/start-a-cbot/
- https://help.ctrader.com/ctrader-algo/documentation/all-algos/compiling/
- https://github.com/features/codespaces
