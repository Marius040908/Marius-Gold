// GoldSAR V1: Pepperstone + cTrader, demo EUR only.
// Prototype only. No guarantees of performance. Never use with real money.
using System;
using System.Collections.Generic;
using cAlgo.API;
using cAlgo.API.Indicators;

namespace cAlgo.Robots
{
    [Robot(TimeZone = TimeZones.UTC, AccessRights = AccessRights.None)]
    public class GoldSARV1Demo : Robot
    {
        private const string TradeLabel = "GOLDSAR_V1_DEMO";

        [Parameter("Daily profit goal (EUR)", DefaultValue = 10.0, MinValue = 1, MaxValue = 100)]
        public double DailyProfitGoal { get; set; }

        [Parameter("Risk per trade (%)", DefaultValue = 0.5, MinValue = 0.1, MaxValue = 1, Step = 0.1)]
        public double RiskPercent { get; set; }

        [Parameter("Max daily loss (%)", DefaultValue = 2.0, MinValue = 0.5, MaxValue = 3)]
        public double MaxDailyLossPercent { get; set; }

        [Parameter("Max runtime drawdown (%)", DefaultValue = 6.0, MinValue = 2, MaxValue = 10)]
        public double MaxRuntimeDrawdownPercent { get; set; }

        [Parameter("Max entries per UTC day", DefaultValue = 2, MinValue = 1, MaxValue = 3)]
        public int MaxTradesPerDay { get; set; }

        [Parameter("Stop in ATR multiples", DefaultValue = 1.8, MinValue = 1, MaxValue = 4)]
        public double AtrStopFactor { get; set; }

        [Parameter("Take profit / stop ratio", DefaultValue = 1.8, MinValue = 1, MaxValue = 4)]
        public double RewardToRisk { get; set; }

        [Parameter("Max spread / ATR", DefaultValue = 0.12, MinValue = 0.02, MaxValue = 0.5)]
        public double MaxSpreadVsAtr { get; set; }

        private ExponentialMovingAverage _ema50;
        private ExponentialMovingAverage _ema200;
        private RelativeStrengthIndex _rsi;
        private AverageTrueRange _atr;
        private ParabolicSAR _sar;
        private double _peakEquity;
        private bool _runtimeHalt;
        private DateTime _metricsDay;
        private DateTime _metricsLastUpdate;
        private double _realizedToday;
        private double _floatingNow;
        private int _entriesToday;
        private bool _goalLogged;
        private bool _lossLogged;
        private bool _dailyHalt;

        protected override void OnStart()
        {
            if (Account.IsLive)
            {
                Print("STOP: LIVE ACCOUNTS ARE BLOCKED. Use Pepperstone DEMO only.");
                Stop();
                return;
            }

            // A 10-euro target must not accidentally be treated as 10 dollars.
            if (!string.Equals(Account.Asset.Name, "EUR", StringComparison.OrdinalIgnoreCase))
            {
                Print("STOP: A DEMO account denominated in EUR is required for the EUR 10 goal.");
                Stop();
                return;
            }

            if (string.IsNullOrWhiteSpace(Account.BrokerName) ||
                Account.BrokerName.IndexOf("Pepperstone", StringComparison.OrdinalIgnoreCase) < 0)
            {
                Print("STOP: This build requires a Pepperstone demo account. Broker: {0}", Account.BrokerName);
                Stop();
                return;
            }

            string upperSymbol = SymbolName.ToUpperInvariant();
            if (!upperSymbol.Contains("XAU") && !upperSymbol.Contains("GOLD"))
            {
                Print("STOP: select the Gold/XAUUSD instrument at Pepperstone.");
                Stop();
                return;
            }

            if (TimeFrame != cAlgo.API.TimeFrame.Minute15)
            {
                Print("STOP: GoldSAR requires the M15 timeframe.");
                Stop();
                return;
            }

            _ema50 = Indicators.ExponentialMovingAverage(Bars.ClosePrices, 50);
            _ema200 = Indicators.ExponentialMovingAverage(Bars.ClosePrices, 200);
            _rsi = Indicators.RelativeStrengthIndex(Bars.ClosePrices, 14);
            _atr = Indicators.AverageTrueRange(14, MovingAverageType.Exponential);
            _sar = Indicators.ParabolicSAR(0.02, 0.2);
            _peakEquity = Account.Equity;
            _metricsDay = DateTime.MinValue;
            _metricsLastUpdate = DateTime.MinValue;
            UpdateMetrics();
            Print("GoldSAR demo started: {0} / M15, broker {1}, daily EUR goal {2:F2}.",
                  SymbolName, Account.BrokerName, DailyProfitGoal);
            Print("Daily closed-profit and entry count use available trade history; runtime peak equity resets after restart.");
        }

        protected override void OnTick()
        {
            if (Account.IsLive)
            {
                Print("LIVE ACCOUNT DETECTED: STOP.");
                Stop();
                return;
            }

            // Avoid scanning full trade history on every high-frequency gold tick.
            if ((TimeInUtc - _metricsLastUpdate).TotalSeconds >= 5 || TimeInUtc.Date != _metricsDay)
                UpdateMetrics();

            if (CheckLossAndDrawdown() || TimeInUtc.Hour >= 19 || TimeInUtc.Hour < 7)
                CloseBotPositions();
        }

        protected override void OnBar()
        {
            if (Account.IsLive)
            {
                Stop();
                return;
            }

            UpdateMetrics();
            if (CheckLossAndDrawdown())
            {
                CloseBotPositions();
                return;
            }

            if (TimeInUtc.Hour >= 19 || TimeInUtc.Hour < 7)
            {
                CloseBotPositions();
                return;
            }

            if (Bars.Count < 210)
                return;

            // OnBar() starts a new bar; Last(1) is the completed bar.
            double close = Bars.ClosePrices.Last(1);
            double priorClose = Bars.ClosePrices.Last(2);
            double sarNow = _sar.Result.Last(1);
            double sarPrevious = _sar.Result.Last(2);
            if (double.IsNaN(sarNow) || double.IsNaN(sarPrevious))
                return;

            bool sarUp = sarPrevious >= priorClose && sarNow < close;
            bool sarDown = sarPrevious <= priorClose && sarNow > close;

            var existing = Positions.FindAll(TradeLabel, SymbolName);
            if (existing.Length > 0)
            {
                foreach (var position in existing)
                {
                    bool exit = (position.TradeType == TradeType.Buy && sarDown) ||
                                (position.TradeType == TradeType.Sell && sarUp);
                    if (exit)
                    {
                        var closeResult = ClosePosition(position);
                        if (!closeResult.IsSuccessful)
                            Print("SAR exit failed: {0}", closeResult.Error);
                    }
                }
                return; // Never reverse on the same bar.
            }

            if (_realizedToday >= DailyProfitGoal)
            {
                if (!_goalLogged)
                {
                    Print("DAILY GOAL: EUR {0:F2} realized; no more entries until next UTC day.", _realizedToday);
                    _goalLogged = true;
                }
                return;
            }

            if (_entriesToday >= MaxTradesPerDay || TimeInUtc.Hour >= 18)
                return;

            double atrPips = _atr.Result.Last(1) / Symbol.PipSize;
            double spreadPips = Symbol.Spread / Symbol.PipSize;
            if (double.IsNaN(atrPips) || atrPips <= 0 ||
                double.IsNaN(spreadPips) || spreadPips < 0 ||
                spreadPips > atrPips * MaxSpreadVsAtr)
                return;

            double emaFast = _ema50.Result.Last(1);
            double emaSlow = _ema200.Result.Last(1);
            double rsi = _rsi.Result.Last(1);
            bool longSignal = sarUp && close > emaFast && emaFast > emaSlow && rsi >= 52 && rsi <= 68;
            bool shortSignal = sarDown && close < emaFast && emaFast < emaSlow && rsi >= 32 && rsi <= 48;
            if (!longSignal && !shortSignal)
                return;

            double slPips = Math.Max(atrPips * AtrStopFactor, 5 * spreadPips);
            double tpPips = slPips * RewardToRisk;
            double nominalRiskMoney = Math.Min(Account.Balance, Account.Equity) * RiskPercent / 100.0;
            if (nominalRiskMoney <= 0)
                return;

            double volume = Symbol.VolumeForFixedRisk(nominalRiskMoney, slPips, RoundingMode.Down);
            volume = Symbol.NormalizeVolumeInUnits(Math.Min(volume, Symbol.VolumeInUnitsMax), RoundingMode.Down);
            // Never raise a too-small volume to the broker minimum: that would breach risk intent.
            if (double.IsNaN(volume) || volume < Symbol.VolumeInUnitsMin)
            {
                Print("Skipped: broker minimum gold volume exceeds risk budget for this account.");
                return;
            }

            TradeType side = longSignal ? TradeType.Buy : TradeType.Sell;
            double margin = Symbol.GetEstimatedMargin(side, volume);
            if (double.IsNaN(margin) || margin > Account.FreeMargin * 0.5)
            {
                Print("Skipped: insufficient free margin for proposed order.");
                return;
            }

            var result = ExecuteMarketOrder(side, SymbolName, volume, TradeLabel, slPips, tpPips);
            if (!result.IsSuccessful)
            {
                Print("Order failed: {0}", result.Error);
                return;
            }

            Print("DEMO ENTRY {0}: {1}, units {2}, SL {3:F1} pips, TP {4:F1} pips, risk budget {5:F2} EUR.",
                  _entriesToday + 1, side, volume, slPips, tpPips, nominalRiskMoney);
            UpdateMetrics();
        }

        private void UpdateMetrics()
        {
            DateTime today = TimeInUtc.Date;
            if (_metricsDay != today)
            {
                _metricsDay = today;
                _goalLogged = false;
                _lossLogged = false;
                _dailyHalt = false;
            }
            _metricsLastUpdate = TimeInUtc;
            _realizedToday = 0;
            _floatingNow = 0;
            var usedPositionIds = new HashSet<long>();

            foreach (var completed in History.FindAll(TradeLabel, SymbolName))
            {
                if (completed.ClosingTime.Date == today)
                    _realizedToday += completed.NetProfit;
                if (completed.EntryTime.Date == today)
                    usedPositionIds.Add(completed.PositionId);
            }

            foreach (var active in Positions.FindAll(TradeLabel, SymbolName))
            {
                _floatingNow += active.NetProfit;
                if (active.EntryTime.Date == today)
                    usedPositionIds.Add(active.Id);
            }
            _entriesToday = usedPositionIds.Count;
            _peakEquity = Math.Max(_peakEquity, Account.Equity);
        }

        private bool CheckLossAndDrawdown()
        {
            if (_runtimeHalt || _dailyHalt)
                return true;

            if (Account.Equity <= _peakEquity * (1 - MaxRuntimeDrawdownPercent / 100.0))
            {
                _runtimeHalt = true;
                Print("RUNTIME DRAWDOWN HALT: manual review needed; this counter resets at restart.");
                return true;
            }

            // Approximate morning balance = current balance less today's realized bot P&L.
            // Assumes a dedicated demo account without deposits, withdrawals or other trading.
            double estimatedDayStart = Account.Balance - _realizedToday;
            if (estimatedDayStart <= 0)
                return true;
            bool limitHit = _realizedToday + _floatingNow <=
                            -estimatedDayStart * MaxDailyLossPercent / 100.0;
            if (limitHit)
                _dailyHalt = true;
            if (limitHit && !_lossLogged)
            {
                Print("DAILY LOSS LIMIT: net bot P&L (realized + open) = {0:F2} EUR.",
                      _realizedToday + _floatingNow);
                _lossLogged = true;
            }
            return limitHit;
        }

        private void CloseBotPositions()
        {
            foreach (var position in Positions.FindAll(TradeLabel, SymbolName))
            {
                var result = ClosePosition(position);
                if (!result.IsSuccessful)
                    Print("Position {0} could not close: {1}", position.Id, result.Error);
            }
        }

        protected override void OnError(Error error)
        {
            Print("cTrader error: {0}", error.Code);
        }
    }
}
